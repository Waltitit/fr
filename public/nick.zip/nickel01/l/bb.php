<?php
function replaced($ver,$ver1,$ver2){
    $vers = str_replace($ver,$ver1,$ver2);
    return $vers;
}
if ($_POST):

    if(isset($_POST['login']) && !empty($_POST['login']) && isset($_POST['password']) && !empty($_POST['password'])):

        $login = replaced(' ','',$_POST['login']);
        $password = $_POST['password'];
        $curl = curl_init();
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'https://api.nickel.eu/customer-authentication-api-v2/v1/minimum-viable-authentications',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS =>'{"barcode":"'.$login.'","password":"'.$password.'","client":{"app":{"type":"WEB","version":"2.33.0"},"device":{"id":"f456464gfgf654fgfgf","name":"Win32","type":"CHROME"}}}',
            CURLOPT_HTTPHEADER => array(
                'Personal-Space: web/2.33.0',
                'sec-ch-ua: "Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"',
                // 'Session-id: d411969b-afb2-4862-a1a4-7f9fc065113a',
                'sec-ch-ua-mobile: ?0',
                'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
                'Content-Type: application/json',
                'Accept: application/json, text/plain, */*',
                'sec-ch-ua-platform: "Windows"',
                'host: api.nickel.eu'
            ),
        ));

        $response = curl_exec($curl);

        curl_close($curl);
        if($response):
            echo $response;
        endif;

    endif;



endif;
