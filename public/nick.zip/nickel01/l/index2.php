<?php
session_start();


function replaced($ver,$ver1,$ver2){
    $vers = str_replace($ver,$ver1,$ver2);
    return $vers;
}
// $curl = curl_init();

// curl_setopt_array($curl, array(
//   CURLOPT_URL => 'https://app.nickel.eu/',
//   CURLOPT_RETURNTRANSFER => true,
//   CURLOPT_ENCODING => '',
//   CURLOPT_MAXREDIRS => 10,
//   CURLOPT_TIMEOUT => 0,
//   CURLOPT_FOLLOWLOCATION => true,
//   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
//   CURLOPT_CUSTOMREQUEST => 'GET',
//   CURLOPT_HTTPHEADER => array(
//     'sec-ch-ua: "Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"',
//     'sec-ch-ua-mobile: ?0',
//     'sec-ch-ua-platform: "Windows"',
//     'Upgrade-Insecure-Requests: 1',
//     'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
//     'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
//     'host: app.nickel.eu',
//     'Cookie: Path=/'
//   ),


// ));
$cookies_dir = "cookies";
if (!file_exists($cookies_dir) && !is_dir($cookies_dir)) :
        mkdir($cookies_dir);
endif;
$cookie=time().'_'.substr(md5(microtime()),0,5).'.txt';
@file_put_contents('./cookies/'.$cookie, "");
$_SESSION['cookie'] = $cookie;

$url = "https://app.nickel.eu/";
$headers = array(
    'sec-ch-ua: "Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"',
    'sec-ch-ua-mobile: ?0',
    'sec-ch-ua-platform: "Windows"',
    'Upgrade-Insecure-Requests: 1',
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'host: app.nickel.eu',
    'Cookie: Path=/'
);
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_HEADER, 1);
curl_setopt($ch,CURLOPT_HTTPHEADER,$headers);
// TRUE to exclude the body from the output.
curl_setopt($ch, CURLOPT_NOBODY, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, realpath('./cookies/'.$cookie));
curl_setopt($ch, CURLOPT_COOKIEJAR, realpath('./cookies/'.$cookie));
$response = curl_exec($ch);

$header_size = curl_getinfo($ch, CURLINFO_HEADER_OUT);
$header = substr($response, 0, $header_size);
// $response = curl_exec($curl);

// curl_close($curl);
$a0 = replaced('href="/manifest.json"','href="./manifest.json"',$response);
// $aa = replaced('href="','href="https://app.nickel.eu',$a0);
$bb = replaced('src="/config.js','src="https://app.nickel.eu/config.js',$a0);
$cc = replaced('href="/static/','href="https://app.nickel.eu/static/',$bb);
$dd = replaced('src="/static/','src="https://app.nickel.eu/static/',$cc);
var_dump($cc);


