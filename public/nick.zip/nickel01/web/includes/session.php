<?php
/**
 * 
 * 
 * @package Function and object class Tools
 * @version 1.3.0
 * @last-modified February 11, 2022
 * @author MSbou ELGHO3T
 * @copyright Copyright (c) 2022, anon
 * @link https://t.me/MarcoSbou_sp
 * 
 * 
 */
/**
 * Powered By ElGHO3T
 */
if (!defined('ELGHO3T_AB_ROOT')) {die("You not have permisions");}
session_start();