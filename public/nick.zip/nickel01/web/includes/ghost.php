<?php

/**
 * 
 * 
 * @package Function and object class Tools
 * @version 1.3.0
 * @last-modified February 11, 2022
 * @author MSbou ELGHO3T
 * @copyright Copyright (c) 2022, anon
 * @link https://t.me/MarcoSbou_sp
 * 
 * 
 */

class ghost
{
    static $stack;

    public $db_file = '';

    public $db = null;

    public $ruslta = null;

    public $rows_count = null;

    public $row_select = null;

    public function __construct($db_file = '',$coonect = true)
    {
        $this->ruslta = array();

        if(!is_file($db_file)):
            throw new Exception( 'SQite3Database: File '.$db_file.' wasn\'t found.' );
        endif;

        $this->db_file 	= $db_file;

        if($coonect):
            $this->connect();
        endif;
    }

    public function __destruct()
    {
        $this->db = null;
    }


    public function connect()
    {

        try{
            $this->db = new SQLite3($this->db_file);
        }catch(Exception $e)
        {
            throw new Exception('SQLite3Database: '.$e->getMessage());
        }

    }

    public function set_qery($query)
    {
        if(!$query)
            return false;
        $aa = $this->db->query($query);
        if($aa):
            return $this->db->query($query);
        endif;
        return false;
    }

    public function get_rows($query ,$return_array = false)
    {
        if(!$query)
            return false;
        $dd= array();
        $aa = $this->db->query($query);

        while($row = $aa->fetchArray(SQLITE3_ASSOC)):
            $dd[] = $row;
        endwhile;
        if(count($dd) > 0):
            if($return_array):
                return $this->ruslta = $dd;
            else:
                return $this->ruslta = (object) $dd;
            endif;
        else:
            
        endif;
        return false;


    }

    public function count_rows($query ,$return_array = false)
    {
        if(!$query)
            return false;
        // $bb = array();

        $aa = $this->db->query($query);

        // $aa->execute();
        $hena = $aa->fetchArray();

        // while($row = $aa->fetchArray(SQLITE3_ASSOC)):
        //     $hena[] = $row;
        // endwhile;
        if($hena):
            if($return_array):
                return $this->rows_count = $hena;
            else:
                return $this->rows_count = (object) $hena;
            endif;
        endif;
        return false;
        // return $hena;

    }

    public function select_row($query ,$userid , $bid, $return_array = false)
    {
        if(!$query || !$userid)
            return false;
        
        $aa = $this->db->prepare($query);

        $aa->bindValue(':userid', $userid, SQLITE3_TEXT);
        $aa->bindValue(':bid', $bid, SQLITE3_TEXT);
        $ab = $aa->execute();
        $aac = $ab->fetchArray();
        if($aac):
            if($return_array):
                return $this->row_select = $aac;
            else:
                return $this->row_select = (object) $aac;
            endif;
        endif;
        return false;
    }
    public function select_row2($query ,$id , $return_array = false)
    {
        if(!$query || !$id)
            return false;
        
        $aa = $this->db->prepare($query);

        $aa->bindValue(':id', $id, SQLITE3_TEXT);
        $ab = $aa->execute();
        $aac = $ab->fetchArray();

        if($aac):
            if($return_array):
                return $this->row_select = $aac;
            else:
                return $this->row_select = (object) $aac;
            endif;
        endif;
        return false;
        // return $aac;
    }

    public function insert_row($query ,$return_array = false)
    {
        if(!$query)
            return false;
        $aa = $this->db->exec($query);
        if($aa):
            return true;
        endif;
        return false;
        // if($return_array):
        //     return $aa;
        // else:
        //     return (object) $aa;
        // endif;
        // return $aa;
    }

    public function update_data($table ,$data , $where, $return_array = false)
    {
        if(!$table || !$data)
            return false;
        // $aa = $this->db->prepare($query);
        $query = 'UPDATE '.$table;
        // $query .= array_shift(array_keys($table));
        $query .= ' SET';

        $i =0;
        foreach($data as $name => $value):
            $query .= ' '.$name ." =||'\n'|| ".$value;
            if( $i < count( $data ) - 1):
                $query .= ',';
            endif;
            $i++;
        endforeach;
        $query .= ' WHERE';

        $i = 0;

        foreach($where as $value):
            $query .= ' '.$value;
            if( $i < count( $where ) - 1)
                $query .= ',';
            $i++;
        endforeach;

        $query .= ';';

        return $query;
    }

    public function update_data_db($query ,$id ,$updtss)
    {

        if(!$query)
            return false;
        
        $aa = $this->db->prepare($query);
        $aa->bindValue(':id', $id, SQLITE3_TEXT);
        $aa->bindValue(':updtss', $updtss, SQLITE3_TEXT);
        $ab = $aa->execute();

        if($ab)
            return true;
        return false;

    }
    public function delet($query ,$id )
    {

        if(!$query)
            return false;
        
        $aa = $this->db->prepare($query);
        $aa->bindValue(':id', $id, SQLITE3_TEXT);
        // $aa->bindValue(':updtss', $updtss, SQLITE3_TEXT);
        $ab = $aa->execute();
        if($ab)
            return true;
        return false;

    }
}

/**
 * 
 * 
 * @package Function and object class Tools
 * @version 1.3.0
 * @last-modified February 11, 2022
 * @author MSbou ELGHO3T
 * @copyright Copyright (c) 2022, anon
 * @link https://t.me/MarcoSbou_sp
 * 
 * 
 */
/**
 * Powered By ElGHO3T
 */